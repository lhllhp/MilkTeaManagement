create PROCEDURE xoaKH
        @maKhachHang int
        as
    begin
      delete from KhachHang
      where maKhachHang = @maKhachHang
    end
go

