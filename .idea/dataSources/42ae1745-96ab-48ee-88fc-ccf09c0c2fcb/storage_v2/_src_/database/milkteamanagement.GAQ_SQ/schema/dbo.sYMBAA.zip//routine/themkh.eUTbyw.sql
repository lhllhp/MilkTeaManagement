CREATE PROCEDURE themKH
        @sdt char(10),
        @diem int
        as
    begin
      INSERT INTO KhachHang
      VALUES (@sdt, @diem)
    end
go

