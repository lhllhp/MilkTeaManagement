CREATE PROCEDURE SelectKH
  as
  begin
    SELECT * FROM KhachHang
  end
go

