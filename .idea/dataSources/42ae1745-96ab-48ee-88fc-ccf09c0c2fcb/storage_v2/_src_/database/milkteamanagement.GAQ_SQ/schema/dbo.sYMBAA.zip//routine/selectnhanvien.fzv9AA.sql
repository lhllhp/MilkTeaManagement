CREATE PROCEDURE SelectNhanVien
  as
  begin 
    SELECT * FROM NhanVien
  end
go

