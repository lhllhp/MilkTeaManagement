CREATE PROCEDURE xoaNV
    @maNV int
as
  begin
    delete from NhanVien
    where maNV = @maNV
  end
go

