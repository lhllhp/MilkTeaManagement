create PROCEDURE suaKH
        @maKhachHang int,
        @sdt char(10),
        @diem int
        as
    begin
      update KhachHang set sdt = @sdt, diem = @diem
      where maKhachHang = @maKhachHang
    end
go

